import csv

soubor = open('complex.csv', 'r', encoding='utf-8')
ctenar = csv.DictReader(soubor)

moje_data = {}

for x in ctenar:
    try:
        cislo = x['cislo_objednavky']
        cena = float(x['cena_za_kus'].replace(',', '.'))
        kusy = float(x['mnozstvi'].replace(',', '.'))
        
        if cena <= 0 or x['nazev_polozky'] == "" or kusy <= 0:
            continue
            
        if cislo not in moje_data:
            moje_data[cislo] = {
                "zakaznik": x['zakaznik'],
                "stav_platby": x['zaplaceno'],
                "celkova_cena": 0,
                "pocet_kusu": 0
            }
        
        moje_data[cislo]["celkova_cena"] = moje_data[cislo]["celkova_cena"] + (cena * kusy)
        moje_data[cislo]["pocet_kusu"] = moje_data[cislo]["pocet_kusu"] + kusy
        
    except:
        continue

soubor.close()

seznam_final = []
for klic in moje_data:
    objednavka = moje_data[klic]
    
    if objednavka["stav_platby"].lower() == "true":
        seznam_final.append(objednavka)

seznam_final.sort(key=lambda x: x["celkova_cena"], reverse=True)

print("Vysledky")
for o in seznam_final:
    print("Zakaznik: " + o["zakaznik"]  +" - " + " Cena:" + str(o["celkova_cena"]) +" Kč " +" - " + "Kusy:" + str(o["pocet_kusu"]))