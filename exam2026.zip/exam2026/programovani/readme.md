Jak spustit program:
naistalujte si Python
Do slozky vlozte datovy soubor complex.csv
Otevrete terminal
zadejte command: python python.py